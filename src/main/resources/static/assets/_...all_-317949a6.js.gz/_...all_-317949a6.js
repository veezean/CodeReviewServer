
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as u}from"./index.vue_vue_type_script_setup_true_name_SvgIcon_lang-dfa84782.js";import{o as d,u as p}from"./vue-router-8228f7a0.js";import{j as f,r as m,o as v,a3 as h,k as y,l as I,E as n,m as t,y as k,C as w,D as x,u as g,af as B,ag as C}from"./runtime-core.esm-bundler-a63aef9e.js";import{b as s}from"./route-block-83d24a4e.js";import{_ as N}from"./_plugin-vue_export-helper-c27b6911.js";const _=o=>(B("data-v-207550e4"),o=o(),C(),o),b={class:"notfound"},S={class:"content"},V=_(()=>t("h1",null,"404",-1)),D=_(()=>t("div",{class:"desc"}," 抱歉，你访问的页面不存在 ",-1)),c=f({__name:"[...all]",setup(o){const r=p(),e=m({inter:NaN,countdown:5});d(()=>{e.value.inter&&clearInterval(e.value.inter)}),v(()=>{e.value.inter=setInterval(()=>{e.value.countdown--,e.value.countdown===0&&(e.value.inter&&clearInterval(e.value.inter),a())},1e3)});function a(){r.push("/")}return(E,R)=>{const l=u,i=h("el-button");return y(),I("div",b,[n(l,{name:"404",class:"icon"}),t("div",S,[V,D,n(i,{type:"primary",onClick:a},{default:k(()=>[w(x(g(e).countdown)+" 秒后，返回首页 ",1)]),_:1})])])}}});typeof s=="function"&&s(c);const q=N(c,[["__scopeId","data-v-207550e4"]]);export{q as default};
//# sourceMappingURL=_...all_-317949a6.js.map
