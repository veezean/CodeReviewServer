
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as v,z as M,B as S,r as B,a as x,o as e,I as f,g as p,e as s,c as a,b as n,f as i,j as T,M as h,U as w,G as N,J as o,t as V,T as z,_ as H,n as I}from"./index-04c83304.js";import L from"./index-33b2b9e4.js";import R from"./index-973bc8e4.js";import{u as $}from"./useMenu-6019a310.js";const b={key:0},j={class:"header-container"},D={class:"main"},E=["onClick"],F={key:1},G=v({name:"Header"}),J=v({...G,setup(U){const l=M(),_=S(),{switchTo:k}=$(),d=B();function g(r){d.value.scrollBy({left:(r.deltaY||r.detail)>0?50:-50})}return(r,W)=>{const y=H,C=x("el-icon");return e(),f(z,{name:"header"},{default:p(()=>[s(l).mode==="pc"&&s(l).settings.menu.menuMode==="head"?(e(),a("header",b,[n("div",j,[n("div",D,[i(L),n("div",{ref_key:"navRef",ref:d,class:"nav",onWheel:T(g,["prevent"])},[(e(!0),a(h,null,w(s(_).allMenus,(t,c)=>{var u,m;return e(),a(h,{key:c},[t.children&&t.children.length!==0?(e(),a("div",{key:0,class:N(["item-container",{active:c===s(_).actived}])},[n("div",{class:"item",onClick:Y=>s(k)(c)},[(u=t.meta)!=null&&u.icon?(e(),f(C,{key:0},{default:p(()=>[i(y,{name:t.meta.icon},null,8,["name"])]),_:2},1024)):o("",!0),(m=t.meta)!=null&&m.title?(e(),a("span",F,V(t.meta.title),1)):o("",!0)],8,E)],2)):o("",!0)],64)}),128))],544)]),i(R)])])):o("",!0)]),_:1})}}});const P=I(J,[["__scopeId","data-v-377a8372"]]);export{P as default};
//# sourceMappingURL=index-0fe2071e.js.map
