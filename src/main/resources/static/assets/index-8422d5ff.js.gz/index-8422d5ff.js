
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{u as p}from"./settings-58b03ff3.js";import{j as i,r,a as f,a3 as g,k as o,x as d,y as h,l,u as e,B as c,D as k,q as y}from"./runtime-core.esm-bundler-a63aef9e.js";import{_ as w}from"./_plugin-vue_export-helper-c27b6911.js";const x=""+new URL("logo-8a5431ff.png",import.meta.url).href,B=["src"],C={key:1},L=i({name:"Logo"}),v=i({...L,props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(s){const n=p(),a=r("CodeReview系统"),_=r(x),m=f(()=>{const t={};return n.settings.home.enable&&(t.name="home"),t});return(t,S)=>{const u=g("router-link");return o(),d(u,{to:e(m),class:y(["title",{"is-link":e(n).settings.home.enable}]),title:e(a)},{default:h(()=>[s.showLogo?(o(),l("img",{key:0,src:e(_),class:"logo"},null,8,B)):c("",!0),s.showTitle?(o(),l("span",C,k(e(a)),1)):c("",!0)]),_:1},8,["to","class","title"])}}});const T=w(v,[["__scopeId","data-v-aa5c78ce"]]);export{T as default};
//# sourceMappingURL=index-8422d5ff.js.map
