
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as i,z as g,e,o as s,c as o,t as a,J as c,M as h,k as y,p as d,l as u,b as r,n as l}from"./index-fcfafe90.js";const p=n=>(d("data-v-78f522ee"),n=n(),u(),n),m={key:0,class:"copyright"},f=p(()=>r("span",null,"Copyright",-1)),k=p(()=>r("span",{class:"icon"},"©",-1)),b={key:0},S=["href"],v={key:1},x={key:2,href:"https://beian.miit.gov.cn/",target:"_blank",rel:"noopener"},C=i({name:"Copyright"}),I=i({...C,setup(n){const _=y(),t=g();return(w,B)=>e(_).meta.copyright??e(t).settings.copyright.enable?(s(),o("footer",m,[f,k,e(t).settings.copyright.dates?(s(),o("span",b,a(e(t).settings.copyright.dates),1)):c("",!0),e(t).settings.copyright.company?(s(),o(h,{key:1},[e(t).settings.copyright.website?(s(),o("a",{key:0,href:e(t).settings.copyright.website,target:"_blank",rel:"noopener"},a(e(t).settings.copyright.company),9,S)):(s(),o("span",v,a(e(t).settings.copyright.company),1))],64)):c("",!0),e(t).settings.copyright.beian?(s(),o("a",x,a(e(t).settings.copyright.beian),1)):c("",!0)])):c("",!0)}});const V=l(I,[["__scopeId","data-v-78f522ee"]]);export{V as _};
//# sourceMappingURL=index-d253de1f.js.map
