
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{u as g}from"./settings-9db32632.js";import{b as h}from"./vue-router-8228f7a0.js";import{j as r,u as t,k as s,l as o,D as a,B as i,F as y,af as d,ag as m,m as c}from"./runtime-core.esm-bundler-a63aef9e.js";import{_ as u}from"./_plugin-vue_export-helper-c27b6911.js";const p=n=>(d("data-v-78f522ee"),n=n(),m(),n),l={key:0,class:"copyright"},f=p(()=>c("span",null,"Copyright",-1)),k=p(()=>c("span",{class:"icon"},"©",-1)),b={key:0},S=["href"],v={key:1},x={key:2,href:"https://beian.miit.gov.cn/",target:"_blank",rel:"noopener"},B=r({name:"Copyright"}),C=r({...B,setup(n){const _=h(),e=g();return(I,w)=>t(_).meta.copyright??t(e).settings.copyright.enable?(s(),o("footer",l,[f,k,t(e).settings.copyright.dates?(s(),o("span",b,a(t(e).settings.copyright.dates),1)):i("",!0),t(e).settings.copyright.company?(s(),o(y,{key:1},[t(e).settings.copyright.website?(s(),o("a",{key:0,href:t(e).settings.copyright.website,target:"_blank",rel:"noopener"},a(t(e).settings.copyright.company),9,S)):(s(),o("span",v,a(t(e).settings.copyright.company),1))],64)):i("",!0),t(e).settings.copyright.beian?(s(),o("a",x,a(t(e).settings.copyright.beian),1)):i("",!0)])):i("",!0)}});const j=u(C,[["__scopeId","data-v-78f522ee"]]);export{j as _};
//# sourceMappingURL=index-3176e7a0.js.map
