
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as i,k as m,a as s,o as _,c as f,f as t,g as e,I as k,e as c,b as a,t as v,i as h,T as w,_ as g,O as x,p as y,l as I,n as V}from"./index-fcfafe90.js";const b=n=>(y("data-v-9f7a005e"),n=n(),I(),n),B={class:"link-view"},C={class:"container"},S=b(()=>a("div",{class:"title"}," 是否访问此链接 ",-1)),N={class:"link"},T=i({name:"LinkView"}),L=i({...T,setup(n){const o=m();function l(){window.open(o.meta.link,"_blank")}return(D,E)=>{const p=g,d=s("el-icon"),r=s("el-button"),u=x;return _(),f("div",B,[t(w,{name:"link",mode:"out-in",appear:""},{default:e(()=>[(_(),k(u,{key:c(o).meta.link,title:"⚠️访问提醒"},{default:e(()=>[a("div",C,[S,a("div",N,v(c(o).meta.link),1),t(r,{type:"primary",plain:"",round:"",onClick:l},{icon:e(()=>[t(d,null,{default:e(()=>[t(p,{name:"ep:link"})]),_:1})]),default:e(()=>[h(" 立即访问 ")]),_:1})])]),_:1}))]),_:1})])}}});const R=V(L,[["__scopeId","data-v-9f7a005e"]]);export{R as default};
//# sourceMappingURL=link-af215666.js.map
