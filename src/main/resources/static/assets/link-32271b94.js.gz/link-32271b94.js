
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as u}from"./index-74c80a46.js";import{_ as f}from"./index.vue_vue_type_script_setup_true_name_SvgIcon_lang-dfa84782.js";import{T as k}from"./runtime-dom.esm-bundler-1ceaee55.js";import{b as v}from"./vue-router-8228f7a0.js";import{j as c,a3 as s,k as _,l as h,E as t,y as e,x as w,u as i,m as a,D as x,C as y,af as g,ag as C}from"./runtime-core.esm-bundler-a63aef9e.js";import{_ as V}from"./_plugin-vue_export-helper-c27b6911.js";const b=o=>(g("data-v-9f7a005e"),o=o(),C(),o),B={class:"link-view"},I={class:"container"},S=b(()=>a("div",{class:"title"}," 是否访问此链接 ",-1)),N={class:"link"},T=c({name:"LinkView"}),D=c({...T,setup(o){const n=v();function l(){window.open(n.meta.link,"_blank")}return(E,L)=>{const p=f,r=s("el-icon"),m=s("el-button"),d=u;return _(),h("div",B,[t(k,{name:"link",mode:"out-in",appear:""},{default:e(()=>[(_(),w(d,{key:i(n).meta.link,title:"⚠️访问提醒"},{default:e(()=>[a("div",I,[S,a("div",N,x(i(n).meta.link),1),t(m,{type:"primary",plain:"",round:"",onClick:l},{icon:e(()=>[t(r,null,{default:e(()=>[t(p,{name:"ep:link"})]),_:1})]),default:e(()=>[y(" 立即访问 ")]),_:1})])]),_:1}))]),_:1})])}}});const F=V(D,[["__scopeId","data-v-9f7a005e"]]);export{F as default};
//# sourceMappingURL=link-32271b94.js.map
