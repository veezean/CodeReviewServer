
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as v}from"./index.vue_vue_type_script_setup_true_name_SvgIcon_lang-dfa84782.js";import{j as i,r as g,w as h,a3 as l,k as c,l as _,n as x,E as o,y as t,u as r,C as y,D as B,B as C}from"./runtime-core.esm-bundler-a63aef9e.js";import{_ as k}from"./_plugin-vue_export-helper-c27b6911.js";const w={class:"search-container"},b={key:0,class:"more"},N=i({name:"SearchBar"}),S=i({...N,props:{showMore:{type:Boolean,default:!1},unfold:{type:Boolean,default:!1}},emits:["toggle"],setup(n,{emit:u}){const a=n,e=g(!a.unfold);h(()=>a.unfold,()=>s(),{immediate:!0});function s(){e.value=!e.value,u("toggle",e.value)}return(d,V)=>{const m=v,p=l("el-icon"),f=l("el-button");return c(),_("div",w,[x(d.$slots,"default",{},void 0,!0),n.showMore?(c(),_("div",b,[o(f,{text:"",size:"small",onClick:s},{icon:t(()=>[o(p,null,{default:t(()=>[o(m,{name:r(e)?"ep:caret-top":"ep:caret-bottom"},null,8,["name"])]),_:1})]),default:t(()=>[y(" "+B(r(e)?"收起":"展开"),1)]),_:1})])):C("",!0)])}}});const $=k(S,[["__scopeId","data-v-9a63a098"]]);export{$ as _};
//# sourceMappingURL=index-c4dfb300.js.map
