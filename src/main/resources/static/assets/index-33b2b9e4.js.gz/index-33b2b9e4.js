
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as i,z as g,r as c,C as p,a as d,o,I as f,g as h,c as l,e,J as r,t as k,G as w,n as y}from"./index-04c83304.js";const C=""+new URL("logo-8a5431ff.png",import.meta.url).href,x=["src"],L={key:1},v=i({name:"Logo"}),B=i({...v,props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(s){const n=g(),a=c("CodeReview系统"),_=c(C),u=p(()=>{const t={};return n.settings.home.enable&&(t.name="home"),t});return(t,S)=>{const m=d("router-link");return o(),f(m,{to:e(u),class:w(["title",{"is-link":e(n).settings.home.enable}]),title:e(a)},{default:h(()=>[s.showLogo?(o(),l("img",{key:0,src:e(_),class:"logo"},null,8,x)):r("",!0),s.showTitle?(o(),l("span",L,k(e(a)),1)):r("",!0)]),_:1},8,["to","class","title"])}}});const z=y(B,[["__scopeId","data-v-35cc1223"]]);export{z as default};
//# sourceMappingURL=index-33b2b9e4.js.map
