
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as g,z as M,B as S,a as b,o as t,I as d,g as u,e as s,c as n,f as m,b as p,M as f,U as C,G as y,J as c,t as B,T as x,_ as w,n as N}from"./index-04c83304.js";import T from"./index-33b2b9e4.js";import{u as V}from"./useMenu-6019a310.js";const z={key:0,class:"main-sidebar-container"},I={class:"nav"},L=["title","onClick"],$=g({name:"MainSidebar"}),D=g({...$,setup(E){const a=M(),i=S(),{switchTo:v}=V();return(F,G)=>{const h=w,k=b("el-icon");return t(),d(x,{name:"main-sidebar"},{default:u(()=>[s(a).settings.menu.menuMode==="side"||s(a).mode==="mobile"&&s(a).settings.menu.menuMode!=="single"?(t(),n("div",z,[m(T,{"show-title":!1,class:"sidebar-logo"}),p("div",I,[(t(!0),n(f,null,C(s(i).allMenus,(e,o)=>{var l,r,_;return t(),n(f,null,[e.children&&e.children.length!==0?(t(),n("div",{key:o,class:y(["item",{active:o===s(i).actived}]),title:((l=e.meta)==null?void 0:l.title)??"[ 无标题 ]",onClick:J=>s(v)(o)},[(r=e.meta)!=null&&r.icon?(t(),d(k,{key:0},{default:u(()=>[m(h,{name:e.meta.icon},null,8,["name"])]),_:2},1024)):c("",!0),p("span",null,B(((_=e.meta)==null?void 0:_.title)??"[ 无标题 ]"),1)],10,L)):c("",!0)],64)}),256))])])):c("",!0)]),_:1})}}});const A=N(D,[["__scopeId","data-v-ca6131e0"]]);export{A as default};
//# sourceMappingURL=index-99bbe310.js.map
