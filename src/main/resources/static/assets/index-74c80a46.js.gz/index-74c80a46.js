
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as f}from"./index.vue_vue_type_script_setup_true_name_SvgIcon_lang-dfa84782.js";import{j as _,v as y,r as g,a3 as v,k as a,l as o,n as i,F as h,C as k,D as C,B as c,u as s,E as r,y as S,q as x,t as B}from"./runtime-core.esm-bundler-a63aef9e.js";import{_ as w}from"./_plugin-vue_export-helper-c27b6911.js";const D={key:0,class:"title-container"},N=_({name:"PageMain"}),V=_({...N,props:{title:{type:String,default:""},collaspe:{type:Boolean,default:!1},height:{type:String,default:""}},setup(e){const p=e,n=!!y().title,t=g(p.collaspe);function u(){t.value=!1}return(l,$)=>{const d=f,m=v("el-icon");return a(),o("div",{class:x(["page-main",{"is-collaspe":s(t)}]),style:B({height:s(t)?e.height:""})},[n||e.title?(a(),o("div",D,[n?i(l.$slots,"title",{key:0},void 0,!0):(a(),o(h,{key:1},[k(C(e.title),1)],64))])):c("",!0),i(l.$slots,"default",{},void 0,!0),s(t)?(a(),o("div",{key:1,class:"collaspe",title:"展开",onClick:u},[r(m,null,{default:S(()=>[r(d,{name:"ep:arrow-down"})]),_:1})])):c("",!0)],6)}}});const j=w(V,[["__scopeId","data-v-88e35152"]]);export{j as _};
//# sourceMappingURL=index-74c80a46.js.map
