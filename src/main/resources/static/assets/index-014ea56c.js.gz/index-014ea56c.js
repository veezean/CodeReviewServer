
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{_ as S}from"./index.vue_vue_type_script_setup_true_name_SvgIcon_lang-dfa84782.js";import{T as b}from"./runtime-dom.esm-bundler-1ceaee55.js";import y from"./index-8422d5ff.js";import{u as C}from"./settings-58b03ff3.js";import{b7 as M}from"./user-2b228075.js";import{u as x}from"./useMenu-ceefac36.js";import{j as g,a3 as B,k as t,x as _,y as u,u as o,l as s,E as d,m as p,F as f,Y as w,q as N,B as i,D as T}from"./runtime-core.esm-bundler-a63aef9e.js";import{_ as V}from"./_plugin-vue_export-helper-c27b6911.js";import"./index-c228ae8f.js";import"./vue-router-8228f7a0.js";import"./index-e71fcdfa.js";import"./index-74c80a46.js";import"./route-block-83d24a4e.js";const D={key:0,class:"main-sidebar-container"},E={class:"nav"},F=["title","onClick"],L=g({name:"MainSidebar"}),$=g({...L,setup(j){const n=C(),r=M(),{switchTo:v}=x();return(q,z)=>{const h=S,k=B("el-icon");return t(),_(b,{name:"main-sidebar"},{default:u(()=>[o(n).settings.menu.menuMode==="side"||o(n).mode==="mobile"&&o(n).settings.menu.menuMode!=="single"?(t(),s("div",D,[d(y,{"show-title":!1,class:"sidebar-logo"}),p("div",E,[(t(!0),s(f,null,w(o(r).allMenus,(e,a)=>{var c,m,l;return t(),s(f,null,[e.children&&e.children.length!==0?(t(),s("div",{key:a,class:N(["item",{active:a===o(r).actived}]),title:((c=e.meta)==null?void 0:c.title)??"[ 无标题 ]",onClick:I=>o(v)(a)},[(m=e.meta)!=null&&m.icon?(t(),_(k,{key:0},{default:u(()=>[d(h,{name:e.meta.icon},null,8,["name"])]),_:2},1024)):i("",!0),p("span",null,T(((l=e.meta)==null?void 0:l.title)??"[ 无标题 ]"),1)],10,F)):i("",!0)],64)}),256))])])):i("",!0)]),_:1})}}});const Z=V($,[["__scopeId","data-v-ca6131e0"]]);export{Z as default};
//# sourceMappingURL=index-014ea56c.js.map
