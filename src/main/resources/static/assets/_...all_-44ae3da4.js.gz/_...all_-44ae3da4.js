
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
  
import{d as i,r as d,s as p,x as v,a as f,o as m,c as h,f as a,b as o,g as x,i as I,t as w,e as y,m as g,_ as k,p as B,l as N,n as b,q as s}from"./index-fcfafe90.js";const c=t=>(B("data-v-207550e4"),t=t(),N(),t),C={class:"notfound"},S={class:"content"},V=c(()=>o("h1",null,"404",-1)),R=c(()=>o("div",{class:"desc"}," 抱歉，你访问的页面不存在 ",-1)),_=i({__name:"[...all]",setup(t){const l=g(),e=d({inter:NaN,countdown:5});p(()=>{e.value.inter&&clearInterval(e.value.inter)}),v(()=>{e.value.inter=setInterval(()=>{e.value.countdown--,e.value.countdown===0&&(e.value.inter&&clearInterval(e.value.inter),n())},1e3)});function n(){l.push("/")}return(q,D)=>{const r=k,u=f("el-button");return m(),h("div",C,[a(r,{name:"404",class:"icon"}),o("div",S,[V,R,a(u,{type:"primary",onClick:n},{default:x(()=>[I(w(y(e).countdown)+" 秒后，返回首页 ",1)]),_:1})])])}}});typeof s=="function"&&s(_);const L=b(_,[["__scopeId","data-v-207550e4"]]);export{L as default};
//# sourceMappingURL=_...all_-44ae3da4.js.map
